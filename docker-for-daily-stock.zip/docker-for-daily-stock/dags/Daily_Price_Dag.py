
from airflow import DAG
from airflow.operators.python_operator import PythonOperator
from datetime import datetime
import requests
import pandas as pd
import os
import boto3

#Run the script
def run_amzn_stock_script():

    exec(open('/opt/airflow/Include/AMZN_TIME_SERIES_DAILY_ADJUSTED.py').read())
    

with DAG('Run_Daily_Price_Dag', 
         description='DAG for running AMZN stock script',
         schedule_interval='0 17 * * 1-5',
         start_date=datetime(2023, 1, 1),
         catchup=False) as dag:

    run_script_task = PythonOperator(task_id='run_amzn_stock_script',
                                     python_callable=run_amzn_stock_script)